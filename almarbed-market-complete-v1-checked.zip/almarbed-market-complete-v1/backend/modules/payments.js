// محولات دفع قابلة للربط الرسمي لاحقًا.
// لا يتم تنفيذ أي تحويل مالي حقيقي في هذه النسخة.
function createPaymentIntent({method,amount,orderId}) {
  if(!['zaincash','kicard','manual'].includes(method)) throw new Error('طريقة دفع غير مدعومة');
  return {status:'pending',method,amount,orderId,requiresProviderCredentials:method!=='manual'};
}
module.exports={createPaymentIntent};
