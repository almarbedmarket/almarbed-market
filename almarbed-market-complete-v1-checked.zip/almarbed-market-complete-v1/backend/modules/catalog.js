const categories=[
 {id:'cars',name:'السيارات',subcategories:['بيع سيارات','تأجير سيارات','قطع غيار','خدمات سيارات']},
 {id:'real-estate',name:'العقارات',subcategories:['بيع','إيجار','أراضٍ','محلات']},
 {id:'shopping',name:'التسوق',subcategories:['إلكترونيات','منزل','أزياء','مواد غذائية']},
 {id:'services',name:'الخدمات',subcategories:['صيانة','نقل','تعليم','خدمات مهنية']}
];
const locations={العراق:{بغداد:['الكرادة','المنصور','الأعظمية'],البصرة:['العشار','الجزائر','القبلة'],النجف:['المركز','الكوفة']}};
module.exports={categories,locations};
