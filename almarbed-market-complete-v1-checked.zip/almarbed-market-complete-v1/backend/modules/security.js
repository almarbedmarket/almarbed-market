const crypto = require('crypto');
function hashPassword(value){return crypto.createHash('sha256').update(String(value)).digest('hex');}
function createDemoToken(user){return Buffer.from(JSON.stringify({id:user.id,role:user.role})).toString('base64url');}
function parseDemoToken(token){try{return JSON.parse(Buffer.from(token,'base64url').toString('utf8'));}catch{return null;}}
module.exports={hashPassword,createDemoToken,parseDemoToken};
