const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataPath = path.join(__dirname, '..', 'database', 'data.json');

app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

function readData(){ return JSON.parse(fs.readFileSync(dataPath,'utf8')); }
function writeData(data){ fs.writeFileSync(dataPath, JSON.stringify(data,null,2),'utf8'); }
function clean(v){ return typeof v === 'string' ? v.trim() : v; }
function hash(value){ return crypto.createHash('sha256').update(value).digest('hex'); }
function validRole(role){ return ['customer','merchant','supplier','admin'].includes(role); }

app.get('/api/health', (_,res)=>res.json({ok:true,name:'Al Marbed Market API',version:'1.0.1'}));

app.post('/api/auth/register',(req,res)=>{
  const full_name=clean(req.body.full_name), email=clean(req.body.email), phone=clean(req.body.phone);
  const password=req.body.password, role=clean(req.body.role)||'customer';
  if(!full_name || !password || password.length<8 || !validRole(role))
    return res.status(400).json({error:'تحقق من الاسم وكلمة المرور والدور. كلمة المرور 8 أحرف على الأقل.'});
  const data=readData();
  if(data.users.some(u=>u.email===email || (phone && u.phone===phone)))
    return res.status(409).json({error:'البريد أو رقم الهاتف مستخدم مسبقًا.'});
  const user={id:data.users.length+1,full_name,email,phone,password_hash:hash(password),role,status:'active'};
  data.users.push(user); writeData(data);
  res.status(201).json({ok:true,user:{id:user.id,full_name,email,phone,role}});
});

app.post('/api/auth/login',(req,res)=>{
  const email=clean(req.body.email), password=req.body.password;
  const data=readData(), user=data.users.find(u=>u.email===email && u.password_hash===hash(password||''));
  if(!user) return res.status(401).json({error:'بيانات الدخول غير صحيحة.'});
  res.json({ok:true,user:{id:user.id,full_name:user.full_name,email:user.email,role:user.role},token:'demo-'+hash(String(user.id)+email).slice(0,24)});
});

app.get('/api/listings',(req,res)=>{
  const data=readData(); let items=data.listings;
  const {category,q,governorate,condition}=req.query;
  if(category) items=items.filter(x=>x.category===category);
  if(q) items=items.filter(x=>(x.title+' '+(x.description||'')).includes(q));
  if(governorate && governorate!=='كل العراق') items=items.filter(x=>x.governorate===governorate);
  if(condition && condition!=='all') items=items.filter(x=>x.condition===condition);
  res.json({items,total:items.length});
});

app.post('/api/listings',(req,res)=>{
  const body=req.body||{};
  if(!clean(body.title)||!validRole(body.owner_role||'customer')||!['cars','real-estate','shopping','services'].includes(body.category))
    return res.status(400).json({error:'العنوان والقسم والبيانات الأساسية مطلوبة.'});
  const data=readData();
  const item={id:data.listings.length+1,title:clean(body.title),category:body.category,condition:body.condition==='used'?'used':'new',
    price:Number(body.price)||0,governorate:clean(body.governorate)||'كل العراق',city:clean(body.city)||'',district:clean(body.district)||'',
    description:clean(body.description)||'',badge:'جديد'};
  data.listings.push(item); writeData(data); res.status(201).json(item);
});

app.use((err,_,res,next)=>{ console.error(err); res.status(500).json({error:'حدث خطأ داخلي.'}); });
app.get('*',(_,res)=>res.sendFile(path.join(__dirname,'..','frontend','index.html')));
app.listen(PORT,()=>console.log(`Al Marbed Market V3 running on http://localhost:${PORT}`));
