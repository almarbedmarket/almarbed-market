let mode='login';
const form=document.getElementById('authForm');
const fields={name:document.getElementById('name'),email:document.getElementById('email'),phone:document.getElementById('phone'),password:document.getElementById('password'),role:document.getElementById('role'),result:document.getElementById('result')};
function setMode(next){mode=next;fields.name.style.display=next==='register'?'block':'none';fields.phone.style.display=next==='register'?'block':'none';fields.role.style.display=next==='register'?'block':'none';fields.name.required=next==='register';}
document.getElementById('loginTab').addEventListener('click',()=>setMode('login'));
document.getElementById('registerTab').addEventListener('click',()=>setMode('register'));
setMode('login');
form.addEventListener('submit',async event=>{event.preventDefault();fields.result.textContent='جارٍ التنفيذ...';try{const body={full_name:fields.name.value,email:fields.email.value,phone:fields.phone.value,password:fields.password.value,role:fields.role.value};const url=mode==='login'?'/api/auth/login':'/api/auth/register';const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await response.json();fields.result.textContent=data.error||(mode==='login'?'تم تسجيل الدخول تجريبيًا.':'تم إنشاء الحساب تجريبيًا.');}catch(error){fields.result.textContent='تعذر الاتصال بالخادم.';}});
