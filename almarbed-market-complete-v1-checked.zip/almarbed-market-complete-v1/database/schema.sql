CREATE TABLE users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 full_name TEXT NOT NULL,
 email TEXT UNIQUE,
 phone TEXT UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('customer','merchant','supplier','admin')),
 status TEXT NOT NULL DEFAULT 'active',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 category TEXT NOT NULL,
 condition TEXT NOT NULL,
 price INTEGER NOT NULL DEFAULT 0,
 governorate TEXT,
 city TEXT,
 district TEXT,
 description TEXT,
 image_url TEXT,
 owner_id INTEGER,
 status TEXT NOT NULL DEFAULT 'published',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE favorites (user_id INTEGER, listing_id INTEGER, PRIMARY KEY(user_id, listing_id));
CREATE TABLE ad_packages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, days INTEGER, price INTEGER, boost_percent INTEGER DEFAULT 0);
